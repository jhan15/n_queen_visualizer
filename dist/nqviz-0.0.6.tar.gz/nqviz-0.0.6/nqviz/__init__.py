from .n_queen import Nqueen
